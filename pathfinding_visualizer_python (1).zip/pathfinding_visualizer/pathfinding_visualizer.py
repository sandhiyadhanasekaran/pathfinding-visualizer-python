import tkinter as tk
from tkinter import ttk, messagebox
from collections import deque
import heapq
import random
import time

# Pathfinding Visualizer
# Algorithms: BFS, DFS, Dijkstra, A*
# Controls: left-click/drag = wall, right-click = erase, drag Start/End to move.

ROWS, COLS = 22, 32
CELL = 24
PADDING = 2

COLORS = {
    "empty": "#f8fafc",
    "grid": "#cbd5e1",
    "wall": "#1e293b",
    "start": "#22c55e",
    "end": "#ef4444",
    "visited": "#93c5fd",
    "frontier": "#c4b5fd",
    "path": "#facc15",
}

class PathfindingVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Pathfinding Visualizer | Python + Tkinter")
        self.root.configure(bg="#eef2ff")
        self.root.resizable(False, False)

        self.start = (ROWS // 2, 5)
        self.end = (ROWS // 2, COLS - 6)
        self.walls = set()
        self.visited = set()
        self.path = []
        self.running = False
        self.drag_mode = None
        self.mouse_down = False
        self.speed = tk.IntVar(value=12)
        self.algorithm = tk.StringVar(value="A* Search")
        self.status = tk.StringVar(value="Ready — draw walls, choose an algorithm, then visualize.")
        self.stats = tk.StringVar(value="Visited: 0   |   Path length: 0   |   Time: 0.00 ms")

        self._build_ui()
        self.draw()

    def _build_ui(self):
        header = tk.Frame(self.root, bg="#eef2ff")
        header.pack(fill="x", padx=16, pady=(14, 4))
        tk.Label(header, text="Pathfinding Visualizer", font=("Segoe UI", 20, "bold"),
                 fg="#172554", bg="#eef2ff").pack(anchor="w")
        tk.Label(header, text="Explore graph algorithms on an interactive grid",
                 font=("Segoe UI", 10), fg="#475569", bg="#eef2ff").pack(anchor="w", pady=(2, 0))

        controls = tk.Frame(self.root, bg="#eef2ff")
        controls.pack(fill="x", padx=16, pady=10)

        tk.Label(controls, text="Algorithm", bg="#eef2ff", fg="#334155",
                 font=("Segoe UI", 9, "bold")).grid(row=0, column=0, padx=(0, 6), sticky="w")
        combo = ttk.Combobox(controls, textvariable=self.algorithm, state="readonly", width=15,
                             values=["BFS", "DFS", "Dijkstra", "A* Search"])
        combo.grid(row=0, column=1, padx=(0, 10))
        combo.bind("<<ComboboxSelected>>", lambda _e: self.clear_search())

        self._button(controls, "Visualize", self.visualize, "#2563eb").grid(row=0, column=2, padx=4)
        self._button(controls, "Random Maze", self.random_maze, "#7c3aed").grid(row=0, column=3, padx=4)
        self._button(controls, "Clear Search", self.clear_search, "#475569").grid(row=0, column=4, padx=4)
        self._button(controls, "Clear Board", self.clear_board, "#dc2626").grid(row=0, column=5, padx=4)

        speedrow = tk.Frame(self.root, bg="#eef2ff")
        speedrow.pack(fill="x", padx=16, pady=(0, 8))
        tk.Label(speedrow, text="Animation speed", bg="#eef2ff", fg="#334155").pack(side="left")
        tk.Scale(speedrow, from_=1, to=30, orient="horizontal", variable=self.speed,
                 showvalue=False, length=180, bg="#eef2ff", highlightthickness=0,
                 troughcolor="#c7d2fe").pack(side="left", padx=8)
        tk.Label(speedrow, text="Slow  ←       →  Fast", bg="#eef2ff", fg="#64748b").pack(side="left")

        board_frame = tk.Frame(self.root, bg="#cbd5e1", padx=1, pady=1)
        board_frame.pack(padx=16, pady=(0, 8))
        self.canvas = tk.Canvas(board_frame, width=COLS * CELL, height=ROWS * CELL,
                                bg="white", highlightthickness=0)
        self.canvas.pack()
        self.canvas.bind("<Button-1>", self.on_left_click)
        self.canvas.bind("<B1-Motion>", self.on_left_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)
        self.canvas.bind("<Button-3>", self.on_right_click)
        self.canvas.bind("<B3-Motion>", self.on_right_drag)

        legend = tk.Frame(self.root, bg="#eef2ff")
        legend.pack(fill="x", padx=18, pady=(0, 4))
        for label, color in [
            ("Start", COLORS["start"]), ("End", COLORS["end"]),
            ("Wall", COLORS["wall"]), ("Visited", COLORS["visited"]),
            ("Shortest path", COLORS["path"])
        ]:
            item = tk.Frame(legend, bg="#eef2ff")
            item.pack(side="left", padx=(0, 14))
            swatch = tk.Canvas(item, width=12, height=12, bg="#eef2ff", highlightthickness=0)
            swatch.pack(side="left", padx=(0, 4))
            swatch.create_rectangle(1, 1, 11, 11, fill=color, outline=color)
            tk.Label(item, text=label, bg="#eef2ff", fg="#334155",
                     font=("Segoe UI", 9)).pack(side="left")

        tk.Label(self.root, textvariable=self.stats, bg="#eef2ff", fg="#172554",
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=18, pady=(5, 2))
        tk.Label(self.root, textvariable=self.status, bg="#eef2ff", fg="#475569",
                 font=("Segoe UI", 9), wraplength=COLS * CELL).pack(anchor="w", padx=18, pady=(0, 14))

    def _button(self, parent, text, command, color):
        return tk.Button(parent, text=text, command=command, bg=color, fg="white",
                         activebackground=color, activeforeground="white",
                         relief="flat", bd=0, padx=10, pady=7,
                         font=("Segoe UI", 9, "bold"), cursor="hand2")

    def draw(self):
        self.canvas.delete("all")
        for r in range(ROWS):
            for c in range(COLS):
                node = (r, c)
                color = COLORS["empty"]
                if node in self.walls:
                    color = COLORS["wall"]
                if node in self.visited:
                    color = COLORS["visited"]
                if node in self.path:
                    color = COLORS["path"]
                if node == self.start:
                    color = COLORS["start"]
                if node == self.end:
                    color = COLORS["end"]
                x1, y1 = c * CELL, r * CELL
                self.canvas.create_rectangle(x1, y1, x1 + CELL, y1 + CELL,
                                             fill=color, outline=COLORS["grid"], width=1)

    def cell_from_event(self, event):
        c, r = event.x // CELL, event.y // CELL
        if 0 <= r < ROWS and 0 <= c < COLS:
            return (r, c)
        return None

    def on_left_click(self, event):
        if self.running:
            return
        node = self.cell_from_event(event)
        if node is None:
            return
        self.mouse_down = True
        if node == self.start:
            self.drag_mode = "start"
        elif node == self.end:
            self.drag_mode = "end"
        else:
            self.drag_mode = "wall"
            self.clear_search()
            self.walls.symmetric_difference_update({node})
            self.draw()

    def on_left_drag(self, event):
        if self.running or not self.mouse_down:
            return
        node = self.cell_from_event(event)
        if node is None:
            return
        if self.drag_mode in ("start", "end"):
            if node not in self.walls and node != self.start and node != self.end:
                if self.drag_mode == "start":
                    self.start = node
                else:
                    self.end = node
                self.draw()
        elif self.drag_mode == "wall" and node not in (self.start, self.end):
            self.walls.add(node)
            self.draw()

    def on_release(self, _event):
        self.mouse_down = False
        self.drag_mode = None

    def on_right_click(self, event):
        if self.running:
            return
        node = self.cell_from_event(event)
        if node in self.walls:
            self.walls.remove(node)
            self.draw()

    def on_right_drag(self, event):
        self.on_right_click(event)

    def neighbors(self, node):
        r, c = node
        result = []
        for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nr, nc = r + dr, c + dc
            nxt = (nr, nc)
            if 0 <= nr < ROWS and 0 <= nc < COLS and nxt not in self.walls:
                result.append(nxt)
        return result

    def heuristic(self, a, b):
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    def search(self):
        algo = self.algorithm.get()
        parent = {}
        visited_order = []

        if algo == "BFS":
            frontier = deque([self.start])
            seen = {self.start}
            while frontier:
                cur = frontier.popleft()
                visited_order.append(cur)
                if cur == self.end:
                    break
                for nxt in self.neighbors(cur):
                    if nxt not in seen:
                        seen.add(nxt)
                        parent[nxt] = cur
                        frontier.append(nxt)

        elif algo == "DFS":
            frontier = [self.start]
            seen = {self.start}
            while frontier:
                cur = frontier.pop()
                visited_order.append(cur)
                if cur == self.end:
                    break
                for nxt in self.neighbors(cur):
                    if nxt not in seen:
                        seen.add(nxt)
                        parent[nxt] = cur
                        frontier.append(nxt)

        elif algo == "Dijkstra":
            frontier = [(0, self.start)]
            distance = {self.start: 0}
            finalized = set()
            while frontier:
                dist, cur = heapq.heappop(frontier)
                if cur in finalized:
                    continue
                finalized.add(cur)
                visited_order.append(cur)
                if cur == self.end:
                    break
                for nxt in self.neighbors(cur):
                    new_dist = dist + 1
                    if new_dist < distance.get(nxt, float("inf")):
                        distance[nxt] = new_dist
                        parent[nxt] = cur
                        heapq.heappush(frontier, (new_dist, nxt))

        else:  # A* Search
            frontier = [(self.heuristic(self.start, self.end), 0, self.start)]
            g_score = {self.start: 0}
            closed = set()
            while frontier:
                _, g, cur = heapq.heappop(frontier)
                if cur in closed:
                    continue
                closed.add(cur)
                visited_order.append(cur)
                if cur == self.end:
                    break
                for nxt in self.neighbors(cur):
                    tentative = g + 1
                    if tentative < g_score.get(nxt, float("inf")):
                        g_score[nxt] = tentative
                        parent[nxt] = cur
                        f = tentative + self.heuristic(nxt, self.end)
                        heapq.heappush(frontier, (f, tentative, nxt))

        path = []
        if self.end == self.start:
            path = [self.start]
        elif self.end in parent:
            cur = self.end
            path.append(cur)
            while cur != self.start:
                cur = parent[cur]
                path.append(cur)
            path.reverse()

        return visited_order, path

    def visualize(self):
        if self.running:
            return
        self.clear_search()
        self.running = True
        self._set_controls_state("disabled")
        started = time.perf_counter()
        visited_order, path = self.search()
        elapsed_ms = (time.perf_counter() - started) * 1000

        def animate_visited(index=0):
            if index < len(visited_order):
                node = visited_order[index]
                if node not in (self.start, self.end):
                    self.visited.add(node)
                self.draw()
                delay = max(1, 35 - self.speed.get())
                self.root.after(delay, lambda: animate_visited(index + 1))
            else:
                animate_path(0)

        def animate_path(index):
            if index < len(path):
                node = path[index]
                if node not in (self.start, self.end):
                    self.path.append(node)
                self.draw()
                delay = max(1, 45 - self.speed.get())
                self.root.after(delay, lambda: animate_path(index + 1))
            else:
                self.running = False
                self._set_controls_state("normal")
                self.stats.set(
                    f"Visited: {len(visited_order)}   |   Path length: {max(0, len(path)-1)}   |   Search time: {elapsed_ms:.2f} ms"
                )
                if path:
                    self.status.set(f"{self.algorithm.get()} completed. Yellow cells show the path.")
                else:
                    self.status.set("No path found. Try removing some walls.")
        animate_visited()

    def _set_controls_state(self, state):
        for child in self.root.winfo_children():
            self._set_widget_state_recursive(child, state)

    def _set_widget_state_recursive(self, widget, state):
        if isinstance(widget, (tk.Button, ttk.Combobox, tk.Scale)):
            try:
                widget.configure(state=state)
            except tk.TclError:
                pass
        for child in widget.winfo_children():
            self._set_widget_state_recursive(child, state)

    def clear_search(self):
        if self.running:
            return
        self.visited.clear()
        self.path.clear()
        self.stats.set("Visited: 0   |   Path length: 0   |   Search time: 0.00 ms")
        self.status.set("Search cleared. Draw walls or choose another algorithm.")
        self.draw()

    def clear_board(self):
        if self.running:
            return
        self.walls.clear()
        self.visited.clear()
        self.path.clear()
        self.stats.set("Visited: 0   |   Path length: 0   |   Search time: 0.00 ms")
        self.status.set("Board cleared.")
        self.draw()

    def random_maze(self):
        if self.running:
            return
        self.walls.clear()
        self.visited.clear()
        self.path.clear()
        for r in range(ROWS):
            for c in range(COLS):
                node = (r, c)
                if node not in (self.start, self.end) and random.random() < 0.27:
                    self.walls.add(node)
        self.stats.set("Visited: 0   |   Path length: 0   |   Search time: 0.00 ms")
        self.status.set("Random obstacles generated. Some layouts may not have a valid path.")
        self.draw()


def main():
    root = tk.Tk()
    app = PathfindingVisualizer(root)
    root.mainloop()

if __name__ == "__main__":
    main()
