# Pathfinding Visualizer (Python)

An interactive graph-algorithm visualizer built with Python and Tkinter.

## Features
- Breadth-First Search (BFS)
- Depth-First Search (DFS)
- Dijkstra's algorithm
- A* Search with Manhattan-distance heuristic
- Click-and-drag wall drawing
- Right-click to erase walls
- Draggable start and end nodes
- Random obstacle generation
- Adjustable animation speed
- Visited-node and path animation
- Displays visited count, path length, and search computation time

## Requirements
- Python 3.9+
- Tkinter (usually included with standard Python installations)

No third-party Python packages are required.

## Run
```bash
python pathfinding_visualizer.py
```

On some Linux systems, install Tkinter if it is missing:
```bash
sudo apt install python3-tk
```

## Controls
- Left-click an empty cell: add a wall
- Left-click a wall: remove it
- Left-click and drag Start/End: move the node
- Right-click a wall: erase it
- Select an algorithm and click **Visualize**
- **Random Maze** generates random obstacles
- **Clear Search** removes visited/path colors
- **Clear Board** removes all obstacles and search results

## Algorithm notes
- BFS finds a shortest path on this unweighted four-directional grid.
- DFS finds a path if one exists, but not necessarily a shortest path.
- Dijkstra finds a shortest path; here every move has equal cost.
- A* uses Manhattan distance and finds a shortest path for this grid setup.

## Resume description
**Pathfinding Visualizer | Python, Tkinter, Graph Algorithms**
Built an interactive desktop application to visualize BFS, DFS, Dijkstra, and A* search on a grid-based graph. Implemented obstacle editing, draggable start/end nodes, randomized layouts, animated exploration and path reconstruction, and metrics for visited nodes, path length, and search time.
